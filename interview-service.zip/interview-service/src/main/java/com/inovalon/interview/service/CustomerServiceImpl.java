/*******************************************************************************
 * Copyright (c) 2019 ? 2020, INOVALON, INC. All Rights Reserved.
 * 
 * This computer program is CONFIDENTIAL and a TRADE SECRET of Inovalon, Inc. 
 * The receipt or possession of this program does not convey any rights to use,
 * reproduce or disclose its contents in whole or in part, without the specific
 * written consent of Inovalon, Inc. Any use, reproduction or disclosure of
 * this program without the express written consent of Inovalon, Inc., is a
 * violation of the copyright laws and may subject you to criminal prosecution.
 ******************************************************************************/

package com.inovalon.interview.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.inovalon.interview.model.Customer;
import com.inovalon.interview.repos.CustomerRepository;
import com.inovalon.interview.resource.CustomerResource;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepository repository;

	@Override
	public List<CustomerResource> getAllCustomers() {
		List<CustomerResource> list = new ArrayList<>();
		List<Customer> customers = repository.findAll();
		if(!CollectionUtils.isEmpty(customers)) {
			for(Customer customer:customers) {
				CustomerResource resource = CustomerResource.builder().build();
				BeanUtils.copyProperties(customer, resource);
				list.add(resource);
			}
		}else {
			log.warn("No data found");
		}
		return list;
	}

}
