package com.inovalon.interview.model;

import java.io.Serializable;
import javax.persistence.*;

import com.inovalon.interview.model.Customer.CustomerBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;


/**
 * The persistent class for the Suppliers database table.
 * 
 */
@Accessors(chain = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="Suppliers")
public class Supplier implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int supplierID;

	private String address;

	private String city;

	private String companyName;

	private String contactName;

	private String contactTitle;

	private String country;

	private String fax;

	@Lob
	private String homePage;

	private String phone;

	private String postalCode;

	private String region;

	//bi-directional many-to-one association to Product
	@OneToMany(mappedBy="supplier")
	private List<Product> products;

}