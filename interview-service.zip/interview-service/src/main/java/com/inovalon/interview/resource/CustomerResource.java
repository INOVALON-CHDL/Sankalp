/*******************************************************************************
 * Copyright (c) 2019 ? 2020, INOVALON, INC. All Rights Reserved.
 * 
 * This computer program is CONFIDENTIAL and a TRADE SECRET of Inovalon, Inc. 
 * The receipt or possession of this program does not convey any rights to use,
 * reproduce or disclose its contents in whole or in part, without the specific
 * written consent of Inovalon, Inc. Any use, reproduction or disclosure of
 * this program without the express written consent of Inovalon, Inc., is a
 * violation of the copyright laws and may subject you to criminal prosecution.
 ******************************************************************************/

package com.inovalon.interview.resource;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Accessors(chain = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerResource implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String customerID;

	private String address;

	private String city;

	private String companyName;

	private String contactName;

	private String contactTitle;

	private String country;

	private String fax;

	private String phone;

	private String postalCode;

	private String region;
}
