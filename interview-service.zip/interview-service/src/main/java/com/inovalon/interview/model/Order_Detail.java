package com.inovalon.interview.model;

import java.io.Serializable;
import javax.persistence.*;

import com.inovalon.interview.model.Employee.EmployeeBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the `Order Details` database table.
 * 
 */
@Accessors(chain = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="`Order Details`")
public class Order_Detail implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private Order_DetailPK id;

	private double discount;

	private short quantity;

	private BigDecimal unitPrice;

	//bi-directional many-to-one association to Order
	@ManyToOne
	@JoinColumn(name="OrderID")
	private Order order;

	//bi-directional many-to-one association to Product
	@ManyToOne
	@JoinColumn(name="ProductID")
	private Product product;
}