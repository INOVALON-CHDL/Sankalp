/*******************************************************************************
 * Copyright (c) 2019 ? 2020, INOVALON, INC. All Rights Reserved.
 * 
 * This computer program is CONFIDENTIAL and a TRADE SECRET of Inovalon, Inc. 
 * The receipt or possession of this program does not convey any rights to use,
 * reproduce or disclose its contents in whole or in part, without the specific
 * written consent of Inovalon, Inc. Any use, reproduction or disclosure of
 * this program without the express written consent of Inovalon, Inc., is a
 * violation of the copyright laws and may subject you to criminal prosecution.
 ******************************************************************************/

package com.inovalon.interview.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableJpaRepositories(basePackages ={"com.inovalon.interview.repos"})
@EntityScan(basePackages = {"com.inovalon.interview.model"})
@EnableTransactionManagement
public class JPAConfig {

}
