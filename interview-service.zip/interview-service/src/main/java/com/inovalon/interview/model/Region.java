package com.inovalon.interview.model;

import java.io.Serializable;
import javax.persistence.*;

import com.inovalon.interview.model.Customer.CustomerBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.util.List;


/**
 * The persistent class for the Region database table.
 * 
 */
@Accessors(chain = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Region implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int regionID;

	private String regionDescription;

	//bi-directional many-to-one association to Territory
	@OneToMany(mappedBy="region")
	private List<Territory> territories;
}