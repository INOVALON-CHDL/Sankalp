package com.inovalon.interview.model;

import java.io.Serializable;
import javax.persistence.*;

import com.inovalon.interview.model.Order.OrderBuilder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the Products database table.
 * 
 */
@Accessors(chain = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="Products")
@NamedQuery(name="Product.findAll", query="SELECT p FROM Product p")
public class Product implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int productID;

	private byte discontinued;

	private String productName;

	private String quantityPerUnit;

	private short reorderLevel;

	private BigDecimal unitPrice;

	private short unitsInStock;

	private short unitsOnOrder;

	//bi-directional many-to-one association to Order_Detail
	@OneToMany(mappedBy="product")
	private List<Order_Detail> orderDetails;

	//bi-directional many-to-one association to Category
	@ManyToOne
	@JoinColumn(name="CategoryID")
	private Category category;

	//bi-directional many-to-one association to Supplier
	@ManyToOne
	@JoinColumn(name="SupplierID")
	private Supplier supplier;
}