package com.inovalon.interview.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;


/**
 * The persistent class for the CustomerDemographics database table.
 * 
 */
@Accessors(chain = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="CustomerDemographics")
@NamedQuery(name="CustomerDemographic.findAll", query="SELECT c FROM CustomerDemographic c")
public class CustomerDemographic implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String customerTypeID;

	@Lob
	private String customerDesc;

	//bi-directional many-to-many association to Customer
	@ManyToMany(mappedBy="customerDemographics")
	private List<Customer> customers;

}