/*******************************************************************************
 * Copyright (c) 2019 ? 2020, INOVALON, INC. All Rights Reserved.
 * 
 * This computer program is CONFIDENTIAL and a TRADE SECRET of Inovalon, Inc. 
 * The receipt or possession of this program does not convey any rights to use,
 * reproduce or disclose its contents in whole or in part, without the specific
 * written consent of Inovalon, Inc. Any use, reproduction or disclosure of
 * this program without the express written consent of Inovalon, Inc., is a
 * violation of the copyright laws and may subject you to criminal prosecution.
 ******************************************************************************/

package com.inovalon.interview.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inovalon.interview.dao.CustomerDAO;
import com.inovalon.interview.resource.CustomerResource;
import com.inovalon.interview.service.CustomerService;

@RestController
@RequestMapping(value = "customer")
public class CustomerController {
	
	@Autowired
	private CustomerService service;
	
	@Autowired
	private CustomerDAO customerDAO;
	
	@GetMapping(value = "jpa", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CustomerResource>> getAllCustomersJpa(){
		List<CustomerResource> list = service.getAllCustomers();
		if(!CollectionUtils.isEmpty(list)) {
			return new ResponseEntity<List<CustomerResource>>(list, HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping(value = "jdbc", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<CustomerResource>> getAllCustomersJdbc(){
		List<CustomerResource> list = customerDAO.findAll();
		if(!CollectionUtils.isEmpty(list)) {
			return new ResponseEntity<List<CustomerResource>>(list, HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
