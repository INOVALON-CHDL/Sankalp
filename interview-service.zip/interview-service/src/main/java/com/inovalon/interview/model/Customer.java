package com.inovalon.interview.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;


/**
 * The persistent class for the Customers database table.
 * 
 */
@Accessors(chain = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="Customers")
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String customerID;

	private String address;

	private String city;

	private String companyName;

	private String contactName;

	private String contactTitle;

	private String country;

	private String fax;

	private String phone;

	private String postalCode;

	private String region;

	//bi-directional many-to-many association to CustomerDemographic
	@ManyToMany
	@JoinTable(name = "CustomerCustomerDemo", joinColumns = { @JoinColumn(name = "CustomerID") }, inverseJoinColumns = {
			@JoinColumn(name = "CustomerTypeID") })
	private List<CustomerDemographic> customerDemographics;

	//bi-directional many-to-one association to Order
	@OneToMany(mappedBy="customer")
	private List<Order> orders;

}