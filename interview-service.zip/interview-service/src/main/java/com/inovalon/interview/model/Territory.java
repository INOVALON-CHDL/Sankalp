package com.inovalon.interview.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * The persistent class for the Territories database table.
 * 
 */
@Accessors(chain = true)
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Territories")
public class Territory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String territoryID;

	private String territoryDescription;

	// bi-directional many-to-many association to Employee
	@ManyToMany
	@JoinTable(name = "EmployeeTerritories", joinColumns = { @JoinColumn(name = "TerritoryID") }, inverseJoinColumns = {
			@JoinColumn(name = "EmployeeID") })
	private List<Employee> employees;

	// bi-directional many-to-one association to Region
	@ManyToOne
	@JoinColumn(name = "RegionID")
	private Region region;
}